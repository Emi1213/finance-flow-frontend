export interface ISignUp {
  email: string;
  password: string;
  name: string;
  lastname: string;
}
