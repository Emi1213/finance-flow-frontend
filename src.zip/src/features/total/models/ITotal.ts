export interface ITotal {
  total: number;
  month: number;
  year: number;
}
