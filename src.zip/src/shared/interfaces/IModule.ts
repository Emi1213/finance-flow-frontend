export interface IModule {
  name: string;
  alias: string;
}
